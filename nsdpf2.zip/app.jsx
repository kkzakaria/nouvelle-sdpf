/* SDPF — App root */
const { HomeScreen, CatalogueScreen, DetailScreen, DevisScreen, ContactScreen } = window.SDPF_SCREENS;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "industriel",
  "accent": "#1e73ad",
  "headingFont": "Archivo",
  "whatsapp": "2250717593030"
}/*EDITMODE-END*/;

const DEVIS_KEY = 'sdpf_devis_v1';
function loadDevis() { try { return JSON.parse(localStorage.getItem(DEVIS_KEY)) || {}; } catch (e) { return {}; } }

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tab, setTab] = useState('home');
  const [detail, setDetail] = useState(null);
  const [nav, setNav] = useState({ token: 0 }); // catalogue init params
  const [devis, setDevis] = useState(loadDevis);

  useEffect(() => { try { localStorage.setItem(DEVIS_KEY, JSON.stringify(devis)); } catch (e) {} }, [devis]);

  const devisCount = Object.keys(devis).length;
  const scrollerRef = useRef(null);

  const go = useCallback((target, params) => {
    setDetail(null);
    if (target === 'catalogue') setNav({ token: Date.now(), cat: params?.cat, query: params?.query });
    setTab(target);
  }, []);

  const openProduct = useCallback((p) => { setDetail(p); }, []);
  useEffect(() => { window.__openProduct = openProduct; }, [openProduct]);

  // scroll to top when switching tab/detail
  useEffect(() => {
    const el = document.querySelector('.app .scroll');
    if (el) el.scrollTop = 0;
  }, [tab, detail]);

  const toggleDevis = useCallback((p) => {
    setDevis((d) => {
      const next = { ...d };
      if (next[p.id]) delete next[p.id]; else next[p.id] = 1;
      return next;
    });
  }, []);
  const setQty = useCallback((id, q) => {
    setDevis((d) => { const next = { ...d }; if (q <= 0) delete next[id]; else next[id] = Math.min(q, 999); return next; });
  }, []);
  const removeItem = useCallback((id) => setDevis((d) => { const n = { ...d }; delete n[id]; return n; }), []);
  const clearAll = useCallback(() => setDevis({}), []);

  const goTab = (id) => { setDetail(null); setTab(id); };

  let screen;
  if (detail) {
    screen = <DetailScreen product={detail} back={() => setDetail(null)} devis={devis} toggleDevis={toggleDevis} wa={t.whatsapp} />;
  } else if (tab === 'home') {
    screen = <HomeScreen go={go} openProduct={openProduct} devis={devis} toggleDevis={toggleDevis} wa={t.whatsapp} />;
  } else if (tab === 'catalogue') {
    screen = <CatalogueScreen openProduct={openProduct} devis={devis} toggleDevis={toggleDevis} initial={nav} />;
  } else if (tab === 'devis') {
    screen = <DevisScreen devis={devis} setQty={setQty} removeItem={removeItem} clearAll={clearAll} go={go} wa={t.whatsapp} />;
  } else {
    screen = <ContactScreen wa={t.whatsapp} />;
  }

  const titles = { home: '', catalogue: 'Catalogue', devis: 'Mon devis', contact: 'Contact' };
  const showBar = !detail && tab !== 'home';

  const titleFf = { Archivo: "'Archivo', sans-serif", Saira: "'Saira', sans-serif", 'Space Grotesk': "'Space Grotesk', sans-serif" }[t.headingFont] || "'Archivo', sans-serif";

  return (
    <div className="app" data-theme={t.theme} style={{ '--accent': t.accent, '--title-ff': titleFf }}>
      {showBar && (
        <AppBar
          title={titles[tab]}
          trailing={tab === 'devis' && devisCount > 0 ? <span className="chip chip-accent">{devisCount}</span> : null}
        />
      )}
      {screen}
      <BottomNav tab={detail ? '' : tab} setTab={goTab} devisCount={devisCount} />

      <TweaksPanel>
        <TweakSection label="Style" />
        <TweakRadio label="Direction" value={t.theme}
          options={['industriel', 'atelier', 'minimal']}
          onChange={(v) => setTweak('theme', v)} />
        <TweakColor label="Couleur d’accent" value={t.accent}
          options={['#1e73ad', '#103a5a', '#b0843a', '#41607a']}
          onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Typographie" />
        <TweakSelect label="Police des titres" value={t.headingFont}
          options={['Archivo', 'Saira', 'Space Grotesk']}
          onChange={(v) => setTweak('headingFont', v)} />
        <TweakSection label="Coordonnées" />
        <TweakText label="N° WhatsApp" value={t.whatsapp}
          onChange={(v) => setTweak('whatsapp', v)} />
      </TweaksPanel>
    </div>
  );
}

// ── Stage: device frame + scale to fit viewport ───────────────────
function Stage() {
  const W = 402, H = 874;
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const fit = () => {
      const s = Math.min((window.innerWidth - 24) / W, (window.innerHeight - 24) / H, 1.12);
      setScale(s > 0 ? s : 1);
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <div id="scaler" style={{ width: W, height: H, transform: `scale(${scale})` }}>
      <IOSDevice width={W} height={H}>
        <App />
      </IOSDevice>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('stage')).render(<Stage />);
