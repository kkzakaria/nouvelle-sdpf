/* SDPF — Catalogue data (plain JS, attached to window) */
(function () {
  const CATS = [
    { id: 'platres',  label: 'Plâtres',               short: 'Plâtres',     desc: 'Plâtres de construction, finition et staff.' },
    { id: 'plaques',  label: 'Plaques & Carreaux',     short: 'Plaques',     desc: 'Plaques BA13, hydrofuges et carreaux de plâtre.' },
    { id: 'filasse',  label: 'Filasse & Étanchéité',   short: 'Filasse',     desc: 'Filasse de lin, étoupe et pâtes d’étanchéité.' },
    { id: 'finition', label: 'Finition & Accessoires', short: 'Finition',    desc: 'Bandes, enduits à joint, profilés et colles.' },
  ];

  const P = [
    // — Plâtres —
    { id: 'platre-construction', cat: 'platres', name: 'Plâtre de construction', fmt: 'Sac 25 kg',
      desc: 'Gros plâtre pour cloisons, scellements et raccords.',
      long: 'Plâtre gros grain destiné aux travaux courants de cloisonnement, au scellement de boîtiers et aux raccords. Prise régulière et bonne accroche sur supports usuels.' },
    { id: 'platre-finition', cat: 'platres', name: 'Plâtre de finition', fmt: 'Sac 25 kg',
      desc: 'Enduit fin pour lissage et finition des surfaces.',
      long: 'Plâtre fin pour le lissage, le rebouchage et la finition soignée des murs et plafonds intérieurs. Surface prête à peindre après ponçage léger.' },
    { id: 'platre-projeter', cat: 'platres', name: 'Plâtre à projeter', fmt: 'Sac 30 kg',
      desc: 'Formulé pour l’application mécanisée sur grandes surfaces.',
      long: 'Plâtre allégé adapté à la machine à projeter pour un rendement élevé sur les grandes surfaces. Temps de travail optimisé pour le dressage et le lissage.' },
    { id: 'platre-staff', cat: 'platres', name: 'Plâtre à mouler / staff', fmt: 'Sac 25 kg',
      desc: 'Plâtre dur pour moulures, corniches et éléments de staff.',
      long: 'Plâtre fin et dur pour le moulage, les corniches, rosaces et éléments décoratifs en staff. Finesse de grain et blancheur pour un rendu net.' },

    // — Plaques & carreaux —
    { id: 'plaque-ba13', cat: 'plaques', name: 'Plaque de plâtre BA13', fmt: '2,5 × 1,2 m',
      desc: 'Plaque standard pour cloisons et doublages intérieurs.',
      long: 'Plaque de plâtre standard 13 mm pour la réalisation de cloisons, doublages et plafonds en intérieur sec. Bords amincis pour un traitement de joint invisible.' },
    { id: 'plaque-hydro', cat: 'plaques', name: 'Plaque hydrofuge', fmt: '2,5 × 1,2 m',
      desc: 'Traitée anti-humidité, pour cuisines et salles de bain.',
      long: 'Plaque à âme hydrofuge pour les pièces humides : cuisines, salles de bain et buanderies. Reconnaissable à son parement traité contre l’humidité.' },
    { id: 'carreau-std', cat: 'plaques', name: 'Carreau de plâtre', fmt: '66 × 50 cm',
      desc: 'Carreau plein pour cloisons rapides et isolantes.',
      long: 'Carreau de plâtre plein à emboîtement pour monter rapidement des cloisons et gaines techniques, avec un bon confort acoustique et thermique.' },
    { id: 'carreau-hydro', cat: 'plaques', name: 'Carreau hydrofuge', fmt: '66 × 50 cm',
      desc: 'Carreau traité pour les pièces humides.',
      long: 'Carreau de plâtre hydrofuge teinté pour repérage, destiné aux cloisons des locaux humides. Montage rapide à la colle plâtre.' },

    // — Filasse & étanchéité —
    { id: 'filasse-lin', cat: 'filasse', name: 'Filasse de lin', fmt: 'Pelote',
      desc: 'Fibre de lin peignée pour l’étanchéité des raccords filetés.',
      long: 'Filasse de lin longue fibre, peignée, pour réaliser l’étanchéité des raccords filetés en plomberie et chauffage. À utiliser avec une pâte d’étanchéité.' },
    { id: 'etoupe-chanvre', cat: 'filasse', name: 'Étoupe de chanvre', fmt: 'Botte',
      desc: 'Fibre naturelle pour calfeutrage et étanchéité.',
      long: 'Étoupe de chanvre naturelle pour le calfeutrage, l’étanchéité et le bourrage. Fibre résistante et durable pour les travaux de plomberie traditionnels.' },
    { id: 'pate-etancheite', cat: 'filasse', name: 'Pâte d’étanchéité', fmt: 'Pot',
      desc: 'À appliquer avec la filasse pour une étanchéité durable.',
      long: 'Pâte à joint non durcissante à associer à la filasse pour garantir l’étanchéité des raccords filetés, eau et gaz. Application facile au pinceau ou à la main.' },

    // — Finition & accessoires —
    { id: 'bande-joint', cat: 'finition', name: 'Bande à joint', fmt: 'Rouleau',
      desc: 'Traitement des joints entre plaques de plâtre.',
      long: 'Bande papier pour le traitement et le renforcement des joints entre plaques de plâtre. Limite la fissuration et assure une surface continue.' },
    { id: 'enduit-joint', cat: 'finition', name: 'Enduit à joint', fmt: 'Sac / Pot',
      desc: 'Pour joints et finitions des plaques.',
      long: 'Enduit pour le collage des bandes, le traitement des joints et la finition des plaques de plâtre. Disponible en poudre à gâcher ou prêt à l’emploi.' },
    { id: 'corniere', cat: 'finition', name: 'Cornière d’angle', fmt: 'Barre 2,5 m',
      desc: 'Profilé de protection pour angles saillants.',
      long: 'Profilé métallique de protection et de dressage des angles saillants avant enduisage. Assure des arêtes droites et résistantes aux chocs.' },
    { id: 'colle-carreaux', cat: 'finition', name: 'Colle pour carreaux', fmt: 'Sac 25 kg',
      desc: 'Colle plâtre pour le montage des carreaux et plaques.',
      long: 'Colle à base de plâtre pour le montage des carreaux de plâtre et le collage des plaques de doublage. Forte adhérence et prise rapide.' },
  ];

  const FEATURED = ['platre-finition', 'plaque-ba13', 'filasse-lin', 'carreau-std'];

  window.SDPF_DATA = { categories: CATS, products: P, featured: FEATURED };
})();
