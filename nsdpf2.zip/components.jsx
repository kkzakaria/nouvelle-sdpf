/* SDPF — shared UI components. Exports to window. */

// ── Icon set (UI iconography, line style) ──────────────────────────
function Icon({ name, size = 22, stroke = 2, color = 'currentColor', style }) {
  const p = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round', style };
  switch (name) {
    case 'home': return (<svg {...p}><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/></svg>);
    case 'grid': return (<svg {...p}><rect x="3" y="3" width="7.5" height="7.5" rx="1"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1"/></svg>);
    case 'doc': return (<svg {...p}><path d="M6 2.5h8l4 4V21a.5.5 0 0 1-.5.5h-11A.5.5 0 0 1 6 21z"/><path d="M14 2.5V7h4"/><path d="M9 12h6M9 15.5h6M9 8.5h2"/></svg>);
    case 'phone': return (<svg {...p}><path d="M5 3.5h3l1.5 4.5-2 1.4a12 12 0 0 0 5.6 5.6l1.4-2 4.5 1.5v3a2 2 0 0 1-2 2A16.5 16.5 0 0 1 3 5.5a2 2 0 0 1 2-2Z"/></svg>);
    case 'search': return (<svg {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.2-3.2"/></svg>);
    case 'plus': return (<svg {...p}><path d="M12 5v14M5 12h14"/></svg>);
    case 'check': return (<svg {...p}><path d="m5 12.5 4.5 4.5L19 6.5"/></svg>);
    case 'chevron': return (<svg {...p}><path d="m9 5 7 7-7 7"/></svg>);
    case 'back': return (<svg {...p}><path d="m15 5-7 7 7 7"/></svg>);
    case 'trash': return (<svg {...p}><path d="M4 6.5h16M9 6.5V4.5h6v2M6 6.5 7 20h10l1-13.5"/></svg>);
    case 'pin': return (<svg {...p}><path d="M12 21s7-6.3 7-11a7 7 0 1 0-14 0c0 4.7 7 11 7 11Z"/><circle cx="12" cy="10" r="2.5"/></svg>);
    case 'mail': return (<svg {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.5 6.5 8.5 6 8.5-6"/></svg>);
    case 'clock': return (<svg {...p}><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>);
    case 'truck': return (<svg {...p}><path d="M3 6.5h11v9H3z"/><path d="M14 9.5h4l3 3v3h-7z"/><circle cx="7" cy="18" r="1.8"/><circle cx="17.5" cy="18" r="1.8"/></svg>);
    case 'layers': return (<svg {...p}><path d="M12 3 21 8l-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/></svg>);
    case 'spark': return (<svg {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18"/></svg>);
    case 'arrow-r': return (<svg {...p}><path d="M5 12h14M13 6l6 6-6 6"/></svg>);
    case 'wa': return (<svg width={size} height={size} viewBox="0 0 24 24" fill={color} style={style}><path d="M12 2a10 10 0 0 0-8.6 15l-1.3 4.8 4.9-1.3A10 10 0 1 0 12 2Zm5.8 14.2c-.25.7-1.45 1.34-2 1.4-.5.06-1.16.08-1.86-.12a14.6 14.6 0 0 1-1.7-.63 11.2 11.2 0 0 1-4.3-3.8c-.32-.44-1.04-1.46-1.04-2.78s.69-1.97.94-2.24a1 1 0 0 1 .72-.34h.52c.17 0 .4-.06.62.47.23.55.78 1.9.85 2.04.07.13.12.3.02.47-.1.18-.15.29-.3.45-.14.16-.3.36-.43.48-.14.14-.29.3-.12.58.16.29.73 1.2 1.56 1.94 1.07.95 1.97 1.25 2.25 1.4.28.13.45.11.61-.07.17-.18.71-.82.9-1.1.18-.29.37-.24.61-.15.25.1 1.57.74 1.84.87.27.14.45.2.51.32.07.11.07.64-.18 1.34Z"/></svg>);
    default: return null;
  }
}

// ── Logo chip (the brand emblem, used in app bars) ─────────────────
function LogoChip({ size = 38 }) {
  return (
    <div className="logo-chip" style={{ width: size, height: size }}>
      <img src="assets/logo-sdpf.jpeg" alt="SDPF" />
    </div>
  );
}

// ── Product photo (image-slot the user can fill, with branded fallback) ──
const CAT_ICON = { platres: 'layers', plaques: 'grid', filasse: 'spark', finition: 'doc' };
window.SDPF_NOSLOT = /noslot/.test(location.search);
function Photo({ product, height, compact = false }) {
  return (
    <div className="photo-wrap" style={{ height: `${height}px` }}>
      <div className="photo-fallback">
        <div className="pf-mark"><Icon name={CAT_ICON[product.cat] || 'layers'} size={compact ? 26 : 40} stroke={1.5} /></div>
        {!compact && <div className="pf-name">{product.name}</div>}
      </div>
      {!window.SDPF_NOSLOT && (
        <image-slot
          id={`prod-${product.id}`}
          class="photo"
          shape="rect"
          placeholder={product.name}
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}
        ></image-slot>
      )}
    </div>
  );
}

// ── Product card (grid) ────────────────────────────────────────────
function ProductCard({ product, onOpen, inDevis, onAdd }) {
  return (
    <div className="card pcard fade-in" onClick={() => onOpen(product)}>
      <Photo product={product} height={120} />
      <div className="pc-body">
        <div className="pc-name">{product.name}</div>
        <div className="pc-desc">{product.desc}</div>
        <div className="pc-foot">
          <span className="chip">{product.fmt}</span>
          <button
            className="add-btn"
            data-in={inDevis ? 'true' : 'false'}
            aria-label="Ajouter au devis"
            onClick={(e) => { e.stopPropagation(); onAdd(product); }}
          >
            <Icon name={inDevis ? 'check' : 'plus'} size={18} stroke={2.6} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Bottom navigation ──────────────────────────────────────────────
function BottomNav({ tab, setTab, devisCount }) {
  const items = [
    { id: 'home', label: 'Accueil', icon: 'home' },
    { id: 'catalogue', label: 'Catalogue', icon: 'grid' },
    { id: 'devis', label: 'Devis', icon: 'doc' },
    { id: 'contact', label: 'Contact', icon: 'phone' },
  ];
  return (
    <nav className="bottomnav">
      {items.map((it) => (
        <button key={it.id} className="navitem" data-on={tab === it.id ? 'true' : 'false'}
          onClick={() => setTab(it.id)}>
          <Icon name={it.icon} size={23} stroke={tab === it.id ? 2.4 : 2} />
          <span>{it.label}</span>
          {it.id === 'devis' && devisCount > 0 && (
            <span className="nav-badge">{devisCount}</span>
          )}
        </button>
      ))}
    </nav>
  );
}

// ── App bar ────────────────────────────────────────────────────────
function AppBar({ title, showLogo = true, leading, trailing }) {
  return (
    <header className="appbar">
      {leading ? leading : (showLogo && <LogoChip />)}
      <div className="bar-title">{title}</div>
      {trailing}
    </header>
  );
}

Object.assign(window, { Icon, LogoChip, Photo, ProductCard, BottomNav, AppBar });
