/* SDPF — screens + app root */

const { useState, useEffect, useRef, useCallback } = React;
const D = window.SDPF_DATA;

const catLabel = (id) => (D.categories.find((c) => c.id === id) || {}).label || '';
const productById = (id) => D.products.find((p) => p.id === id);
const countInCat = (id) => D.products.filter((p) => p.cat === id).length;

function buildWa(number, message) {
  const n = (number || '').replace(/[^0-9]/g, '');
  return `https://wa.me/${n}?text=${encodeURIComponent(message)}`;
}

// ── HOME ────────────────────────────────────────────────────────────
function HomeScreen({ go, openProduct, devis, toggleDevis, wa }) {
  const [q, setQ] = useState('');
  const submit = (e) => { e.preventDefault(); go('catalogue', { query: q }); };
  return (
    <div className="scroll pb-nav">
      {/* hero */}
      <section style={{
        background: 'var(--logo-navy)', color: '#fff', padding: '56px 18px 26px',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'linear-gradient(rgba(255,255,255,.045) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.045) 1px, transparent 1px)',
          backgroundSize: '38px 38px',
        }} />
        <div style={{ position: 'relative' }}>
          <div style={{
            width: 132, height: 132, margin: '6px auto 14px', borderRadius: 18, overflow: 'hidden',
            boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.16), 0 18px 40px rgba(0,0,0,.32)',
          }}>
            <img src="assets/logo-sdpf.jpeg" alt="SDPF" style={{ width: '100%', height: '100%', objectFit: 'cover', transform: 'scale(1.04)' }} />
          </div>
          <div style={{ textAlign: 'center' }}>
            <div className="label" style={{ color: 'rgba(255,255,255,.62)', marginBottom: 10 }}>Nouvelle Société de Distribution</div>
            <h1 className="h-title" style={{ fontSize: 40, letterSpacing: '.04em', color: '#fff' }}>SDPF</h1>
            <p style={{ margin: '8px auto 0', maxWidth: 280, color: 'rgba(255,255,255,.78)', fontSize: 15, lineHeight: 1.45 }}>
              Distribution de plâtre &amp; filasse. La matière première de vos chantiers, au bon endroit.
            </p>
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 22 }}>
            <button className="btn btn-primary btn-block" onClick={() => go('catalogue')}>
              Voir le catalogue <Icon name="arrow-r" size={18} stroke={2.4} />
            </button>
            <button className="btn btn-ghost" style={{ background: 'rgba(255,255,255,.1)', color: '#fff', border: '1px solid rgba(255,255,255,.28)', flexShrink: 0 }} onClick={() => go('devis')}>
              Devis
            </button>
          </div>
        </div>
      </section>

      <div className="pad">
        {/* search */}
        <form className="searchbar" onSubmit={submit} style={{ marginTop: -2 }}>
          <Icon name="search" size={20} />
          <input placeholder="Rechercher un produit…" value={q} onChange={(e) => setQ(e.target.value)} />
        </form>

        {/* value strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginTop: 14 }}>
          {[
            { ic: 'truck', t: 'Livraison', s: 'sur chantier' },
            { ic: 'doc', t: 'Devis', s: 'sous 24 h' },
            { ic: 'layers', t: 'Retrait', s: 'au dépôt' },
          ].map((v) => (
            <div key={v.t} style={{ textAlign: 'center', padding: '12px 6px', background: 'var(--surface)', border: 'var(--card-border)', borderRadius: 'var(--radius)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ color: 'var(--accent)', display: 'flex', justifyContent: 'center', marginBottom: 6 }}><Icon name={v.ic} size={20} /></div>
              <div style={{ fontFamily: 'var(--title-ff)', fontWeight: 700, fontSize: 13 }}>{v.t}</div>
              <div style={{ color: 'var(--muted)', fontSize: 11 }}>{v.s}</div>
            </div>
          ))}
        </div>

        {/* categories */}
        <div className="section-head">
          <span className="sh-title">Nos gammes</span>
          <span className="sh-link" onClick={() => go('catalogue')}>Tout voir</span>
        </div>
        <div className="cat-grid">
          {D.categories.map((c) => (
            <div key={c.id} className="cat-tile" onClick={() => go('catalogue', { cat: c.id })}>
              <div className="ct-mark"><Icon name={catIcon(c.id)} size={78} stroke={1.4} /></div>
              <div className="label" style={{ color: 'var(--accent)' }}>{String(countInCat(c.id)).padStart(2, '0')} réf.</div>
              <div>
                <div className="ct-name">{c.short}</div>
                <div className="ct-count">{c.desc}</div>
              </div>
            </div>
          ))}
        </div>

        {/* featured */}
        <div className="section-head">
          <span className="sh-title">En avant</span>
        </div>
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto', margin: '0 -16px', padding: '2px 16px 6px', scrollbarWidth: 'none' }}>
          {D.featured.map((id) => {
            const p = productById(id);
            return (
              <div key={id} className="card pcard" style={{ width: 168, flexShrink: 0 }} onClick={() => openProduct(p)}>
                <Photo product={p} height={120} />
                <div className="pc-body">
                  <div className="pc-name">{p.name}</div>
                  <div className="pc-foot">
                    <span className="chip">{p.fmt}</span>
                    <button className="add-btn" data-in={devis[p.id] ? 'true' : 'false'} onClick={(e) => { e.stopPropagation(); toggleDevis(p); }}>
                      <Icon name={devis[p.id] ? 'check' : 'plus'} size={18} stroke={2.6} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function catIcon(id) {
  return ({ platres: 'layers', plaques: 'grid', filasse: 'spark', finition: 'doc' })[id] || 'grid';
}

// ── CATALOGUE ───────────────────────────────────────────────────────
function CatalogueScreen({ openProduct, devis, toggleDevis, initial }) {
  const [cat, setCat] = useState(initial.cat || 'all');
  const [q, setQ] = useState(initial.query || '');
  useEffect(() => { if (initial.cat) setCat(initial.cat); if (initial.query != null) setQ(initial.query); }, [initial.token]);

  const list = D.products.filter((p) => {
    const okCat = cat === 'all' || p.cat === cat;
    const s = (q || '').trim().toLowerCase();
    const okQ = !s || (p.name + ' ' + p.desc + ' ' + catLabel(p.cat)).toLowerCase().includes(s);
    return okCat && okQ;
  });

  return (
    <div className="scroll pb-nav">
      <div className="pad">
        <form className="searchbar" onSubmit={(e) => e.preventDefault()}>
          <Icon name="search" size={20} />
          <input placeholder="Rechercher…" value={q} onChange={(e) => setQ(e.target.value)} />
          {q && <span onClick={() => setQ('')} style={{ cursor: 'pointer', color: 'var(--muted)', fontSize: 18 }}>✕</span>}
        </form>

        <div className="filters" style={{ marginTop: 12 }}>
          <button className="fchip" data-on={cat === 'all'} onClick={() => setCat('all')}>Tous</button>
          {D.categories.map((c) => (
            <button key={c.id} className="fchip" data-on={cat === c.id} onClick={() => setCat(c.id)}>{c.short}</button>
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', margin: '18px 0 16px' }}>
          <span className="sh-title" style={{ fontFamily: 'var(--title-ff)', fontWeight: 800, fontSize: 18, lineHeight: 1.1 }}>
            {cat === 'all' ? 'Tous les produits' : catLabel(cat)}
          </span>
          <span className="label" style={{ color: 'var(--muted)' }}>{list.length} réf.</span>
        </div>

        {list.length === 0 ? (
          <div className="empty">
            <div className="em-ic"><Icon name="search" size={44} stroke={1.5} /></div>
            Aucun produit ne correspond.
          </div>
        ) : (
          <div className="pgrid">
            {list.map((p) => (
              <ProductCard key={p.id} product={p} onOpen={openProduct} inDevis={!!devis[p.id]} onAdd={toggleDevis} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── PRODUCT DETAIL ──────────────────────────────────────────────────
function DetailScreen({ product, back, devis, toggleDevis, wa }) {
  const inD = !!devis[product.id];
  const related = D.products.filter((p) => p.cat === product.cat && p.id !== product.id).slice(0, 4);
  const waMsg = `Bonjour SDPF, je souhaite commander / un devis pour :\n• ${product.name} (${product.fmt})\n\nMerci.`;
  return (
    <div className="scroll pb-nav" style={{ background: 'var(--bg)' }}>
      {/* floating back */}
      <button onClick={back} aria-label="Retour" style={{
        position: 'absolute', top: 52, left: 14, zIndex: 12,
        width: 42, height: 42, borderRadius: 999, border: 0, cursor: 'pointer',
        background: 'color-mix(in srgb, var(--surface) 80%, transparent)',
        backdropFilter: 'blur(10px)', boxShadow: 'var(--shadow-sm)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink)',
      }}><Icon name="back" size={22} /></button>

      <Photo product={product} height={300} />

      <div className="pad fade-in" style={{ marginTop: -18, position: 'relative', background: 'var(--bg)', borderTopLeftRadius: 22, borderTopRightRadius: 22 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 10, paddingTop: 6 }}>
          <span className="chip chip-accent">{catLabel(product.cat)}</span>
          <span className="chip">{product.fmt}</span>
        </div>
        <h1 className="h-title" style={{ fontSize: 26 }}>{product.name}</h1>
        <p style={{ color: 'var(--muted)', fontSize: 15, lineHeight: 1.5, marginTop: 12 }}>{product.long}</p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 22 }}>
          <button className={'btn btn-block btn-lg ' + (inD ? 'btn-brand' : 'btn-primary')} onClick={() => toggleDevis(product)}>
            <Icon name={inD ? 'check' : 'plus'} size={20} stroke={2.4} />
            {inD ? 'Ajouté au devis' : 'Ajouter au devis'}
          </button>
          <a className="btn btn-wa btn-block btn-lg" href={buildWa(wa, waMsg)} target="_blank" rel="noopener">
            <Icon name="wa" size={20} /> Commander via WhatsApp
          </a>
        </div>

        {related.length > 0 && (
          <>
            <div className="section-head"><span className="sh-title">Dans la même gamme</span></div>
            <div style={{ display: 'flex', gap: 12, overflowX: 'auto', margin: '0 -16px', padding: '2px 16px 6px', scrollbarWidth: 'none' }}>
              {related.map((p) => (
                <div key={p.id} className="card pcard" style={{ width: 150, flexShrink: 0 }} onClick={() => { back(); setTimeout(() => window.__openProduct(p), 30); }}>
                  <Photo product={p} height={104} />
                  <div className="pc-body"><div className="pc-name" style={{ fontSize: 13 }}>{p.name}</div></div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── DEVIS (panier) ──────────────────────────────────────────────────
function DevisScreen({ devis, setQty, removeItem, clearAll, go, wa }) {
  const ids = Object.keys(devis);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [note, setNote] = useState('');

  const message = (() => {
    let m = 'Bonjour SDPF, voici ma demande de devis :\n\n';
    ids.forEach((id) => { const p = productById(id); m += `• ${p.name} — ${devis[id]} × (${p.fmt})\n`; });
    if (name) m += `\nNom : ${name}`;
    if (phone) m += `\nTél : ${phone}`;
    if (note) m += `\nNote : ${note}`;
    m += '\n\nMerci.';
    return m;
  })();

  if (ids.length === 0) {
    return (
      <div className="scroll pb-nav">
        <div className="empty" style={{ paddingTop: 90 }}>
          <div className="em-ic"><Icon name="doc" size={52} stroke={1.4} /></div>
          <div style={{ fontFamily: 'var(--title-ff)', fontWeight: 700, fontSize: 18, color: 'var(--ink)', marginBottom: 6 }}>Votre devis est vide</div>
          <p style={{ maxWidth: 240, margin: '0 auto 20px' }}>Ajoutez des produits depuis le catalogue pour préparer votre demande.</p>
          <button className="btn btn-primary" onClick={() => go('catalogue')}>Parcourir le catalogue</button>
        </div>
      </div>
    );
  }

  return (
    <div className="scroll pb-nav">
      <div className="pad">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <span className="label" style={{ color: 'var(--muted)' }}>{ids.length} produit{ids.length > 1 ? 's' : ''}</span>
          <span className="sh-link" style={{ color: 'var(--muted)', cursor: 'pointer' }} onClick={clearAll}>Vider</span>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {ids.map((id) => {
            const p = productById(id);
            return (
              <div key={id} className="card" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 10 }}>
                <div style={{ width: 64, height: 64, flexShrink: 0, borderRadius: 'calc(var(--radius) - 4px)', overflow: 'hidden' }}>
                  <Photo product={p} height={64} compact />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'var(--title-ff)', fontWeight: 700, fontSize: 14, lineHeight: 1.2 }}>{p.name}</div>
                  <div style={{ color: 'var(--muted)', fontSize: 12, marginTop: 2 }}>{p.fmt}</div>
                  <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div className="qty">
                      <button onClick={() => setQty(id, devis[id] - 1)}>−</button>
                      <span>{devis[id]}</span>
                      <button onClick={() => setQty(id, devis[id] + 1)}>+</button>
                    </div>
                    <button onClick={() => removeItem(id)} aria-label="Retirer" style={{ border: 0, background: 'none', cursor: 'pointer', color: 'var(--muted)' }}><Icon name="trash" size={18} /></button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* contact form */}
        <div className="section-head"><span className="sh-title">Vos coordonnées</span></div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div><label className="field-label">Nom / Société</label><input className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex. Chantier Atlas SARL" /></div>
          <div><label className="field-label">Téléphone</label><input className="field" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="06 00 00 00 00" /></div>
          <div><label className="field-label">Note (optionnel)</label><textarea className="field" rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Délais, lieu de livraison…" /></div>
        </div>

        <a className="btn btn-wa btn-block btn-lg" style={{ marginTop: 18 }} href={buildWa(wa, message)} target="_blank" rel="noopener">
          <Icon name="wa" size={20} /> Envoyer la demande via WhatsApp
        </a>
        <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 12, marginTop: 10 }}>
          Votre demande s’ouvre dans WhatsApp, prête à envoyer. Réponse sous 24 h.
        </p>
      </div>
    </div>
  );
}

// ── CONTACT ─────────────────────────────────────────────────────────
function ContactScreen({ wa }) {
  const rows = [
    { ic: 'pin', t: 'Adresse', s: 'Treichville, Abidjan — Avenue 16, Rue 38 (près de la pharmacie)' },
    { ic: 'phone', t: 'Téléphone', s: '+225 07 17 59 30 30' },
    { ic: 'mail', t: 'Boîte postale', s: '25 BP 1343 Abidjan 25' },
    { ic: 'clock', t: 'Horaires', s: 'Lun – Sam · 8h – 18h' },
  ];
  return (
    <div className="scroll pb-nav">
      <section style={{ background: 'var(--logo-navy)', color: '#fff', padding: '54px 18px 28px', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(255,255,255,.045) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.045) 1px, transparent 1px)', backgroundSize: '38px 38px' }} />
        <div style={{ position: 'relative' }}>
          <LogoChip size={64} />
          <h1 className="h-title" style={{ fontSize: 26, marginTop: 14, color: '#fff' }}>Parlons de votre chantier</h1>
          <p style={{ color: 'rgba(255,255,255,.76)', fontSize: 14, marginTop: 8, maxWidth: 280, marginInline: 'auto' }}>Conseil produit, devis ou commande — l’équipe SDPF vous répond.</p>
        </div>
      </section>
      <div className="pad">
        <a className="btn btn-wa btn-block btn-lg" href={buildWa(wa, 'Bonjour SDPF, j’aimerais des informations.')} target="_blank" rel="noopener"><Icon name="wa" size={20} /> Écrire sur WhatsApp</a>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 16 }}>
          {rows.map((r) => (
            <div key={r.t} className="card" style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px' }}>
              <div style={{ width: 40, height: 40, borderRadius: 'var(--chip-r)', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'color-mix(in srgb, var(--accent) 12%, transparent)', color: 'var(--accent)' }}><Icon name={r.ic} size={20} /></div>
              <div><div className="label" style={{ color: 'var(--muted)' }}>{r.t}</div><div style={{ fontFamily: 'var(--title-ff)', fontWeight: 600, fontSize: 15, marginTop: 2 }}>{r.s}</div></div>
            </div>
          ))}
        </div>
        <div className="card" style={{ marginTop: 12, height: 150, position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(var(--line) 1px, transparent 1px), linear-gradient(90deg, var(--line) 1px, transparent 1px)', backgroundSize: '26px 26px', opacity: .8 }} />
          <div style={{ position: 'relative', color: 'var(--accent)' }}><Icon name="pin" size={34} /></div>
          <span style={{ position: 'absolute', bottom: 10, fontSize: 11, color: 'var(--muted)', fontFamily: 'var(--label-ff)' }}>EMPLACEMENT À DÉFINIR</span>
        </div>
        <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 11.5, marginTop: 16 }}>
          Nouvelle Société de Distribution de Plâtre et Filasses · SDPF
        </p>
      </div>
    </div>
  );
}

window.SDPF_SCREENS = { HomeScreen, CatalogueScreen, DetailScreen, DevisScreen, ContactScreen };
