/* SDPF — Desktop catalogue app */
const { useState, useEffect, useRef, useCallback } = React;
const DD = window.SDPF_DATA;
const dCatLabel = (id) => (DD.categories.find((c) => c.id === id) || {}).label || '';
const dProductById = (id) => DD.products.find((p) => p.id === id);
const dCountInCat = (id) => DD.products.filter((p) => p.cat === id).length;
const dCatIcon = { platres: 'layers', plaques: 'grid', filasse: 'spark', finition: 'doc' };
function dBuildWa(number, message) {
  const n = (number || '').replace(/[^0-9]/g, '');
  return `https://wa.me/${n}?text=${encodeURIComponent(message)}`;
}
const WA_NUMBER = '2250717593030';
const DDEVIS_KEY = 'sdpf_devis_v1';
function dLoadDevis() { try { return JSON.parse(localStorage.getItem(DDEVIS_KEY)) || {}; } catch (e) { return {}; } }

function DHeader({ devisCount, openDrawer, goTo, refs }) {
  return (
    <header className="dhead">
      <div className="wrap">
        <div className="dbrand" onClick={() => goTo(refs.top)}>
          <LogoChip size={42} />
          <div className="bw"><b>SDPF</b><span>Plâtre &amp; Filasse</span></div>
        </div>
        <nav className="dnav">
          <a onClick={() => goTo(refs.top)}>Accueil</a>
          <a onClick={() => goTo(refs.gammes)}>Nos gammes</a>
          <a onClick={() => goTo(refs.catalogue)}>Catalogue</a>
          <a onClick={() => goTo(refs.contact)}>Contact</a>
        </nav>
        <div className="h-actions">
          <a className="btn btn-wa" href={dBuildWa(WA_NUMBER, 'Bonjour SDPF, j’aimerais des informations.')} target="_blank" rel="noopener">
            <Icon name="wa" size={18} /> WhatsApp
          </a>
          <button className="devis-btn" onClick={openDrawer}>
            <Icon name="doc" size={18} stroke={2.2} /> Mon devis
            {devisCount > 0 && <span className="dcount">{devisCount}</span>}
          </button>
        </div>
      </div>
    </header>
  );
}

function DHero({ goTo, refs, onSearch }) {
  const [q, setQ] = useState('');
  const submit = (e) => { e.preventDefault(); onSearch(q); goTo(refs.catalogue); };
  return (
    <section className="dhero">
      <div className="grid-tex" />
      <div className="wrap">
        <div>
          <span className="label" style={{ color: 'rgba(255,255,255,.62)', fontFamily: 'var(--label-ff)', letterSpacing: '.14em', textTransform: 'uppercase', fontSize: 12 }}>Nouvelle Société de Distribution</span>
          <h1>Le plâtre &amp; la filasse,<br />au cœur de vos chantiers.</h1>
          <p className="lead">Distribution professionnelle de plâtres, plaques, carreaux, filasse et accessoires de finition. Devis rapide et livraison sur chantier.</p>
          <form className="hero-search" onSubmit={submit}>
            <Icon name="search" size={20} color="rgba(255,255,255,.7)" />
            <input placeholder="Rechercher un produit…" value={q} onChange={(e) => setQ(e.target.value)} />
          </form>
          <div className="hero-cta">
            <button className="btn btn-primary btn-lg" onClick={() => goTo(refs.catalogue)}>Voir le catalogue <Icon name="arrow-r" size={18} stroke={2.4} /></button>
            <button className="btn btn-ghost btn-lg" style={{ background: 'rgba(255,255,255,.1)', color: '#fff', border: '1px solid rgba(255,255,255,.28)' }} onClick={() => goTo(refs.gammes)}>Nos gammes</button>
          </div>
        </div>
        <div className="hero-logo">
          <img src="assets/logo-sdpf.jpeg" alt="SDPF" />
        </div>
      </div>
      <div className="wrap" style={{ paddingTop: 0, paddingBottom: 0 }}>
        <div className="vstrip">
          {[{ ic: 'truck', t: 'Livraison', s: 'sur chantier' }, { ic: 'doc', t: 'Devis', s: 'sous 24 h' }, { ic: 'layers', t: 'Retrait', s: 'au dépôt' }].map((v) => (
            <div key={v.t}><div style={{ color: 'var(--accent)' }}><Icon name={v.ic} size={26} /></div><div><div className="vt">{v.t}</div><div className="vs">{v.s}</div></div></div>
          ))}
        </div>
      </div>
    </section>
  );
}

function DGammes({ goTo, refs, setCat }) {
  return (
    <section className="dsection" style={{ background: 'var(--surface)' }}>
      <div className="wrap">
        <div className="dsec-head">
          <div className="lab">Catalogue</div>
          <h2>Nos gammes</h2>
          <p>Quatre familles de produits pour tous vos travaux de plâtrerie, cloisonnement, étanchéité et finition.</p>
        </div>
        <div className="gamme-grid">
          {DD.categories.map((c) => (
            <div key={c.id} className="gamme-card" onClick={() => { setCat(c.id); goTo(refs.catalogue); }}>
              <div className="gc-mark"><Icon name={dCatIcon[c.id]} size={96} stroke={1.3} /></div>
              <div className="gc-count">{String(dCountInCat(c.id)).padStart(2, '0')} références</div>
              <div><h3>{c.short}</h3><p>{c.desc}</p></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function DProductCard({ p, inDevis, onOpen, onToggle }) {
  return (
    <div className="dpcard" onClick={() => onOpen(p)}>
      <Photo product={p} height={180} />
      <div className="dpc-body">
        <div className="dpc-name">{p.name}</div>
        <div className="dpc-desc">{p.desc}</div>
        <div className="dpc-foot">
          <span className="chip">{p.fmt}</span>
          <button className="add-btn" data-in={inDevis ? 'true' : 'false'} onClick={(e) => { e.stopPropagation(); onToggle(p); }} aria-label="Ajouter au devis">
            <Icon name={inDevis ? 'check' : 'plus'} size={18} stroke={2.6} />
          </button>
        </div>
      </div>
    </div>
  );
}

function DCatalogue({ refs, cat, setCat, query, setQuery, devis, onOpen, onToggle }) {
  const list = DD.products.filter((p) => {
    const okCat = cat === 'all' || p.cat === cat;
    const s = (query || '').trim().toLowerCase();
    const okQ = !s || (p.name + ' ' + p.desc + ' ' + dCatLabel(p.cat)).toLowerCase().includes(s);
    return okCat && okQ;
  });
  return (
    <section className="dsection" ref={refs.catalogue}>
      <div className="wrap">
        <div className="dsec-head">
          <div className="lab">{list.length} références</div>
          <h2>{cat === 'all' ? 'Tous les produits' : dCatLabel(cat)}</h2>
        </div>
        <div className="cat-layout">
          <aside className="cat-side">
            <div className="side-search">
              <Icon name="search" size={18} />
              <input placeholder="Rechercher…" value={query} onChange={(e) => setQuery(e.target.value)} />
              {query && <span style={{ cursor: 'pointer', fontSize: 16 }} onClick={() => setQuery('')}>✕</span>}
            </div>
            <div className="side-block">
              <div className="sb-title">Gammes</div>
              <div className="cat-list">
                <button data-on={cat === 'all'} onClick={() => setCat('all')}><span>Toutes</span><span className="cl-n">{DD.products.length}</span></button>
                {DD.categories.map((c) => (
                  <button key={c.id} data-on={cat === c.id} onClick={() => setCat(c.id)}><span>{c.short}</span><span className="cl-n">{dCountInCat(c.id)}</span></button>
                ))}
              </div>
            </div>
          </aside>
          <div className="dpgrid">
            {list.length === 0 ? (
              <div className="dcat-empty"><div style={{ color: 'var(--line-strong)', marginBottom: 12 }}><Icon name="search" size={44} stroke={1.4} /></div>Aucun produit ne correspond.</div>
            ) : list.map((p) => (
              <DProductCard key={p.id} p={p} inDevis={!!devis[p.id]} onOpen={onOpen} onToggle={onToggle} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function DModal({ product, close, inDevis, onToggle }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [close]);
  const waMsg = `Bonjour SDPF, je souhaite commander / un devis pour :\n• ${product.name} (${product.fmt})\n\nMerci.`;
  return (
    <div className="modal-back" onClick={close}>
      <div className="modal" onClick={(e) => e.stopPropagation()} style={{ position: 'relative' }}>
        <button className="m-close" onClick={close}><Icon name="back" size={20} style={{ transform: 'rotate(0deg)' }} /></button>
        <Photo product={product} height={520} />
        <div className="m-info">
          <div style={{ display: 'flex', gap: 8 }}>
            <span className="chip chip-accent">{dCatLabel(product.cat)}</span>
            <span className="chip">{product.fmt}</span>
          </div>
          <h2>{product.name}</h2>
          <p className="m-long">{product.long}</p>
          <div className="m-actions">
            <button className={'btn btn-block btn-lg ' + (inDevis ? 'btn-brand' : 'btn-primary')} onClick={() => onToggle(product)}>
              <Icon name={inDevis ? 'check' : 'plus'} size={20} stroke={2.4} /> {inDevis ? 'Ajouté au devis' : 'Ajouter au devis'}
            </button>
            <a className="btn btn-wa btn-block btn-lg" href={dBuildWa(WA_NUMBER, waMsg)} target="_blank" rel="noopener"><Icon name="wa" size={20} /> Commander via WhatsApp</a>
          </div>
        </div>
      </div>
    </div>
  );
}

function DDrawer({ devis, setQty, removeItem, clearAll, close, goTo, refs }) {
  const ids = Object.keys(devis);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [note, setNote] = useState('');
  const message = (() => {
    let m = 'Bonjour SDPF, voici ma demande de devis :\n\n';
    ids.forEach((id) => { const p = dProductById(id); m += `• ${p.name} — ${devis[id]} × (${p.fmt})\n`; });
    if (name) m += `\nNom : ${name}`;
    if (phone) m += `\nTél : ${phone}`;
    if (note) m += `\nNote : ${note}`;
    m += '\n\nMerci.';
    return m;
  })();
  return (
    <div className="drawer-back" onClick={close}>
      <div className="drawer" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-head">
          <h3>Mon devis {ids.length > 0 && <span style={{ color: 'var(--muted)', fontWeight: 600, fontSize: 15 }}>· {ids.length}</span>}</h3>
          <button onClick={close} style={{ border: 0, background: 'none', cursor: 'pointer', color: 'var(--muted)', fontSize: 24, lineHeight: 1 }}>✕</button>
        </div>
        {ids.length === 0 ? (
          <div className="drawer-body" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', color: 'var(--muted)' }}>
            <div style={{ color: 'var(--line-strong)', marginBottom: 14 }}><Icon name="doc" size={52} stroke={1.4} /></div>
            <div style={{ fontFamily: 'var(--title-ff)', fontWeight: 700, fontSize: 17, color: 'var(--ink)', marginBottom: 6 }}>Votre devis est vide</div>
            <p style={{ maxWidth: 240, marginBottom: 18 }}>Ajoutez des produits depuis le catalogue.</p>
            <button className="btn btn-primary" onClick={() => { close(); goTo(refs.catalogue); }}>Parcourir le catalogue</button>
          </div>
        ) : (
          <>
            <div className="drawer-body">
              <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 8 }}>
                <span style={{ color: 'var(--muted)', fontSize: 13, cursor: 'pointer' }} onClick={clearAll}>Vider</span>
              </div>
              {ids.map((id) => {
                const p = dProductById(id);
                return (
                  <div key={id} className="drow">
                    <div style={{ width: 56, height: 56, flexShrink: 0, borderRadius: 8, overflow: 'hidden' }}><Photo product={p} height={56} compact /></div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div className="dr-name">{p.name}</div>
                      <div style={{ color: 'var(--muted)', fontSize: 12.5 }}>{p.fmt}</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div className="qty"><button onClick={() => setQty(id, devis[id] - 1)}>−</button><span>{devis[id]}</span><button onClick={() => setQty(id, devis[id] + 1)}>+</button></div>
                      <button onClick={() => removeItem(id)} style={{ border: 0, background: 'none', cursor: 'pointer', color: 'var(--muted)' }}><Icon name="trash" size={17} /></button>
                    </div>
                  </div>
                );
              })}
              <div style={{ marginTop: 18, display: 'flex', flexDirection: 'column', gap: 12 }}>
                <div><label className="field-label">Nom / Société</label><input className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex. Chantier Atlas SARL" /></div>
                <div><label className="field-label">Téléphone</label><input className="field" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="06 00 00 00 00" /></div>
                <div><label className="field-label">Note (optionnel)</label><textarea className="field" rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Délais, lieu de livraison…" /></div>
              </div>
            </div>
            <div className="drawer-foot">
              <a className="btn btn-wa btn-block btn-lg" href={dBuildWa(WA_NUMBER, message)} target="_blank" rel="noopener"><Icon name="wa" size={20} /> Envoyer via WhatsApp</a>
              <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 12, marginTop: 10 }}>Réponse sous 24 h.</p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function DFooter({ refs }) {
  return (
    <footer className="dfoot" ref={refs.contact}>
      <div className="wrap">
        <div className="foot-grid">
          <div>
            <div className="foot-logo"><img src="assets/logo-sdpf.jpeg" alt="SDPF" /></div>
            <p style={{ fontSize: 14, lineHeight: 1.6, margin: 0 }}>Nouvelle Société de Distribution de Plâtre et Filasses. Votre partenaire matériaux pour la plâtrerie et l’étanchéité.</p>
          </div>
          <div>
            <h4>Coordonnées</h4>
            <div className="frow"><Icon name="pin" size={18} /><span>Treichville, Abidjan<br />Avenue 16, Rue 38 — près de la pharmacie</span></div>
            <div className="frow"><Icon name="phone" size={18} /><span>+225 07 17 59 30 30</span></div>
            <div className="frow"><Icon name="mail" size={18} /><span>25 BP 1343 Abidjan 25</span></div>
          </div>
          <div>
            <h4>Horaires</h4>
            <div className="frow"><Icon name="clock" size={18} /><span>Lun – Sam<br />8h – 18h</span></div>
          </div>
          <div>
            <h4>Commande rapide</h4>
            <a className="btn btn-wa" href={dBuildWa(WA_NUMBER, 'Bonjour SDPF, j’aimerais passer commande.')} target="_blank" rel="noopener"><Icon name="wa" size={18} /> WhatsApp</a>
          </div>
        </div>
        <div className="legal">
          <span>© {new Date().getFullYear()} SDPF — Nouvelle Société de Distribution de Plâtre et Filasses</span>
          <span>Catalogue indicatif · prix sur devis</span>
        </div>
      </div>
    </footer>
  );
}

function DApp() {
  const [cat, setCat] = useState('all');
  const [query, setQuery] = useState('');
  const [devis, setDevis] = useState(dLoadDevis);
  const [detail, setDetail] = useState(null);
  const [drawer, setDrawer] = useState(false);
  useEffect(() => { try { localStorage.setItem(DDEVIS_KEY, JSON.stringify(devis)); } catch (e) {} }, [devis]);

  const refs = { top: useRef(null), gammes: useRef(null), catalogue: useRef(null), contact: useRef(null) };
  const rootRef = useRef(null);
  const goTo = useCallback((ref) => {
    if (!ref.current || !rootRef.current) return;
    const sc = rootRef.current.parentElement;
    const scaler = document.getElementById('scaler');
    const scale = scaler ? (scaler.getBoundingClientRect().width / scaler.offsetWidth) : 1;
    const target = Math.max(0, (ref.current.getBoundingClientRect().top - sc.getBoundingClientRect().top) / scale + sc.scrollTop - 80);
    const start = sc.scrollTop, dist = target - start, dur = 440; let t0 = null;
    const step = (ts) => {
      if (t0 == null) t0 = ts;
      const p = Math.min(1, (ts - t0) / dur);
      const e = p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
      sc.scrollTop = start + dist * e;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
    // guarantee: if rAF is throttled and never starts, snap to target
    setTimeout(() => { if (t0 == null) sc.scrollTop = target; }, 80);
  }, []);

  const toggleDevis = useCallback((p) => setDevis((d) => { const n = { ...d }; if (n[p.id]) delete n[p.id]; else n[p.id] = 1; return n; }), []);
  const setQty = useCallback((id, q) => setDevis((d) => { const n = { ...d }; if (q <= 0) delete n[id]; else n[id] = Math.min(q, 999); return n; }), []);
  const removeItem = useCallback((id) => setDevis((d) => { const n = { ...d }; delete n[id]; return n; }), []);
  const clearAll = useCallback(() => setDevis({}), []);
  const devisCount = Object.keys(devis).length;

  return (
    <div className="dsite" ref={rootRef}>
      <span ref={refs.top} />
      <DHeader devisCount={devisCount} openDrawer={() => setDrawer(true)} goTo={goTo} refs={refs} />
      <DHero goTo={goTo} refs={refs} onSearch={(q) => { setQuery(q); setCat('all'); }} />
      <div ref={refs.gammes}><DGammes goTo={goTo} refs={refs} setCat={setCat} /></div>
      <DCatalogue refs={refs} cat={cat} setCat={setCat} query={query} setQuery={setQuery} devis={devis} onOpen={setDetail} onToggle={toggleDevis} />
      <DFooter refs={refs} />

      {detail && <DModal product={detail} close={() => setDetail(null)} inDevis={!!devis[detail.id]} onToggle={toggleDevis} />}
      {drawer && <DDrawer devis={devis} setQty={setQty} removeItem={removeItem} clearAll={clearAll} close={() => setDrawer(false)} goTo={goTo} refs={refs} />}
    </div>
  );
}

function DStage() {
  const W = 1440, H = 900;
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const fit = () => setScale(Math.min((window.innerWidth - 32) / W, (window.innerHeight - 32) / H, 1));
    fit(); window.addEventListener('resize', fit); return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <div id="scaler" style={{ width: W, height: H, transform: `scale(${scale})` }}>
      <ChromeWindow width={W} height={H} url="sdpf.ma/catalogue" tabs={[{ title: 'Catalogue SDPF — Plâtre & Filasse' }]}>
        <DApp />
      </ChromeWindow>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('stage')).render(<DStage />);
